-- AlterTable
ALTER TABLE "User" ADD COLUMN     "desc" TEXT DEFAULT '';
